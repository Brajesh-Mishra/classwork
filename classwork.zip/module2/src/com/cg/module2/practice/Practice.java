package com.cg.module2.practice;

import java.util.LinkedHashSet;
import java.util.Set;

public class Practice {

	public static void main(String[] args) {
	
		String s1="ABC";
		String s2=new String("ABC");
		
	
		
		Set<String> st=new LinkedHashSet<>();
		st.add(s1);
		st.add(s2);
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		
		System.out.println(s1.equals(s2));
		
	}
	
	
}
