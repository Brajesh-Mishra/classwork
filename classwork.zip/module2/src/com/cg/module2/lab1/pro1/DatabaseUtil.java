package com.cg.module2.lab1.pro1;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
public class DatabaseUtil {

	private static String url=null;
	private static String usn=null;
	private static String pwd=null;
	private static String driver=null;
	private static Connection con=null;
	
	public static Connection getConnection() throws SQLException, IOException, ClassNotFoundException 
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Properties properties=getProperties();
		url=properties.getProperty("url");
		usn=properties.getProperty("usn");
		pwd=properties.getProperty("pwd");
		
		
		if(con==null)
		con=DriverManager.getConnection(url, usn, pwd);
	
		return con;
	}
	
	
	public static Properties getProperties() throws IOException {
		Properties properties =new Properties();
		FileReader filereader=new FileReader("dbproperties.properties");
		properties.load(filereader);
		return properties;
	}
	
	
	
	
}
