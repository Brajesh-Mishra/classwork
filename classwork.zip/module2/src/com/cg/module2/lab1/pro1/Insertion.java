package com.cg.module2.lab1.pro1;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Insertion {

	public static void main(String[] args) {
		Connection con;
		PreparedStatement st3;
		
		
		
			try 
			{
					con=DatabaseUtil.getConnection();
					st3=con.prepareStatement("delete from emp1 where emp_id in(select emp_id from emp2) ");
					st3.executeUpdate();
					System.out.println("terminated");
					con.close();
			}
			catch (Exception e){
			
					e.printStackTrace();
			}

	}

}
