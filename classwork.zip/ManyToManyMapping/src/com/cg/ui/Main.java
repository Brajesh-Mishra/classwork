package com.cg.ui;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.beans.Library;
import com.cg.beans.Student;
import com.cg.jpa.Util.Util;

public class Main {

	   public static void main(String[] args) {  
	          
	       
	        EntityManager em=Util.getEntityManager(); 
	          
	        em.getTransaction().begin();  
	          
	        Student st1=new Student(3,"Vipul",null);  
	        Student st2=new Student(4,"Vimal",null);  
	          
	          
	        ArrayList<Student> al1=new ArrayList<Student>();  
	        ArrayList<Student> al2=new ArrayList<Student>();  
	          
	        al1.add(st1);  
	        al1.add(st2);  
	          
	        al2.add(st1);  
	        al2.add(st2);  
	          
	        Library lib1=new Library(103,"Data Structure",al1);  
	        Library lib2=new Library(104,"DBMS",al2);  
	          
	          
	        em.persist(lib1);  
	        em.persist(lib2);  
	          
	        em.getTransaction().commit();  
	        em.close();  
	      
	          
	    }  

}
