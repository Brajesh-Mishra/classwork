package com.cg.beans;

public class Dpartment {

	private int deptNo;
	private String deptNamel;
	
	
	 
	
	public Dpartment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Dpartment(int deptNo, String deptNamel) {
		super();
		this.deptNo = deptNo;
		this.deptNamel = deptNamel;
	}
	@Override
	public String toString() {
		return "Dpartment [deptNo=" + deptNo + ", deptNamel=" + deptNamel + "]";
	}
	public int getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}
	public String getDeptNamel() {
		return deptNamel;
	}
	public void setDeptNamel(String deptNamel) {
		this.deptNamel = deptNamel;
	}
	
	
}
