package src.com.cg.ui;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import src.com.cg.beans.Department;
import src.com.cg.beans.Employee;
import src.com.cg.jpa.Util.Util;

public class Main {

	
	public static void main(String[] args) {
		EntityManager entityManager=Util.getEntityManager();
		EntityTransaction entityTran=entityManager.getTransaction();
		
		Department dept1=new Department();
	
		dept1.setDeptname("HRR");
		
		Employee emp=new Employee();
		emp.setEmpName("brajesh");
		emp.setSalary(1000.000f);
	
		Employee emp1=new Employee();
		emp1.setEmpName("rahul");
		emp1.setSalary(1200.000f);
		
		HashSet<Employee> empSet =new HashSet<>();
		empSet.add(emp);
		empSet.add(emp1);
		
		dept1.setEmpSet(empSet);
		entityTran.begin();
		
		entityManager.persist(dept1);
		
		entityTran.commit();
		
	}
}
