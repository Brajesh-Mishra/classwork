package src.com.cg.beans;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="dept_maste")
public class Department {
	
	@Id
	@Column(name="dept_Code",length=50)
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int deptCode;
	
	@Column(name="dept_name",length=50)
	private String deptname;

	//@OneToMany(targetEntity=Employee.class,cascade=CascadeType.ALL)
	@OneToMany(mappedBy="empDept",cascade=CascadeType.ALL)
	private Set<Employee> empSet=new HashSet<>();
	
	
	
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Department(int deptCode, String deptname) {
		super();
		this.deptCode = deptCode;
		this.deptname = deptname;
	}

	public int getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(int deptCode) {
		this.deptCode = deptCode;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public Set<Employee> getEmpSet() {
		return empSet;
	}

	public void setEmpSet(HashSet<Employee> empSet) {
		this.empSet = empSet;
	}


	
	

}
