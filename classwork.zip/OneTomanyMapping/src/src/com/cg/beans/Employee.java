package src.com.cg.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Emp_maste")
public class Employee {

	@Id
	@Column(name="Emp_id",length=50)
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int empId;
	
	@Column(name="Emmp_name",length=50)
	private String empName;
	
	@Column(name="salary",length=50)
	private float salary;
	
	
	@ManyToOne
	@JoinColumn(name="dept_Code")
	private Department empDept; 
	
	
	
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empId, String empName, float salary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
	}
	
	
	
	
	public Employee(int empId, String empName, float salary, Department empDept) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.empDept = empDept;
	}
	
	public Department getEmpDept() {
		return empDept;
	}
	public void setEmpDept(Department empDept) {
		this.empDept = empDept;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	
	
	
}
