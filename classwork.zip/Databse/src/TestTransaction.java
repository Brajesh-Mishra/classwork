import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class TestTransaction {
	static Connection connection=null;
	public static void main(String[] args) {
	try {
		connection=DatabaseUtil.getConnection();
		connection.setAutoCommit(false);
		
		String update1="update emp1 set emp_name='mishra' where emp_id=111";
		String update2="update emp1 set emp_name='google' where emp_id=222";
		
		Statement st=connection.createStatement();
		
		st.addBatch(update1);
		st.addBatch(update2);
		
		st.executeBatch();
		connection.commit();
		System.out.println("updated sucessfully");
	
	} catch (SQLException | IOException e) {
		
		try {
			connection.rollback();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		e.printStackTrace();
	}

	}

}
