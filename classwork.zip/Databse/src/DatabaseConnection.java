import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DatabaseConnection {

	
	
	public static void main(String[] args) {
		Connection con;
		Statement st;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "Capgemini123");
			st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from emp1");
			System.out.println("EMP_ID\t\tEMP_NAME\t\tEMP_SALARY\t\tEMP_DOJ");
			while(rs.next()){
				System.out.println(rs.getInt("emp_id")+"\t\t"+rs.getString("emp_name")+"\t\t\t"+rs.getInt("emp_salary")+"\t\t"+rs.getDate("emp_doj"));
			}
		
			con.close();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
}
