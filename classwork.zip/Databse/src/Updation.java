import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Updation {

	public static void main(String[] args) {
		Connection con;
		PreparedStatement st;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the EMP_ID want to update");
		int emp_id=	scanner.nextInt();
		scanner.nextLine();
		System.out.println("Enter the EMP_NAME");
		String emp_name=scanner.nextLine();
		
	
	
		
		try {
			
			String query="update emp1 set emp_name=? where emp_id=?";
			con=DatabaseUtil.getConnection();
			st=con.prepareStatement(query);
			st.setString(1,emp_name);
			st.setInt(2, emp_id);
		
			int data=st.executeUpdate();
			System.out.println("Updated");
			
			con.close();
		} catch (Exception e) {
			
			e.printStackTrace();
		}

	}

}
