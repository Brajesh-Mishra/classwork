import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Insertion {

	public static void main(String[] args) {
		Connection con;
		PreparedStatement st;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the EMP_ID & NAME & SALARY");
		int emp_id=	scanner.nextInt();
		scanner.nextLine();
		String emp_name=scanner.nextLine();
		int emp_salary=scanner.nextInt();
	
		
		try {
			
			String query="insert into emp1(emp_id,emp_name,emp_salary) values(?,?,?)";
			con=DatabaseUtil.getConnection();
			st=con.prepareStatement(query);
			st.setInt(1,emp_id);
			st.setString(2, emp_name);
			st.setInt(3,emp_salary);
			int data=st.executeUpdate();
			System.out.println("Data inserted");
			
			con.close();
		} catch (Exception e) {
			
			e.printStackTrace();
		}

	}

}
