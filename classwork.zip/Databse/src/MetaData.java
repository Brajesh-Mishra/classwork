import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class MetaData {

	public static void main(String[] args) {
		Connection con;
		Statement st;
		try {
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "Capgemini123");
			st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from emp1");
			
			ResultSetMetaData rsmd=rs.getMetaData();
			int colCount=rsmd.getColumnCount();
			System.out.println(colCount);
			
			for(int i=1;i<=colCount;i++) 
			{
				System.out.print("Column Name\t"+rsmd.getColumnName(i)+"\tColumn Type\t"+rsmd.getColumnTypeName(i));
				System.out.println();
			}
			con.close();
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}

	}

}
