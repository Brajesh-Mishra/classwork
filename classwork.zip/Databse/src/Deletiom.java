import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Deletiom {

	public static void main(String[] args) {
		Connection con;
		PreparedStatement st;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the EMP_ID want to delete");
		int emp_id=	scanner.nextInt();
	
	
		
		try {
			
			String query="delete from emp1 where emp_id=?";
			con=DatabaseUtil.getConnection();
			st=con.prepareStatement(query);
			st.setInt(1,emp_id);
		
			int data=st.executeUpdate();
			System.out.println("deleted");
			
			con.close();
		} catch (Exception e) {
			
			e.printStackTrace();
		}

	}
}
