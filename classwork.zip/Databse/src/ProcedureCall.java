import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

public class ProcedureCall {

	public static void main(String[] args) {
		
		try {
			Connection connection=DatabaseUtil.getConnection();
			CallableStatement st=connection.prepareCall("call procedure1(?,?)");
			st.setInt(1, 111);
			
			st.registerOutParameter(2, Types.NUMERIC);
			
			ResultSet rs=st.executeQuery();
			
			System.out.println("Salary is "+ st.getInt(2));
			
			
		} catch (SQLException | IOException e) {
			
			e.printStackTrace();
		}

	}

}
