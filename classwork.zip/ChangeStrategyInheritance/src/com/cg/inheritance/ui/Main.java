package com.cg.inheritance.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.inheritance.beans.Emp;
import com.cg.inheritance.beans.Manager;
import com.cg.inheritance.util.Util;

public class Main {

	public static void main(String []args) {
		
		Emp rahul=new Emp();
		rahul.setEmpName("rahul Chauhan");
		rahul.setEmpSalary(1005.55f);
		
		
		Manager manager=new Manager();
		manager.setEmpName("vaishali");
		manager.setEmpSalary(5002.00f);
		manager.setDeptName("Java");
		
		EntityManager em=Util.getEntityManager();
		EntityTransaction entityTran=em.getTransaction();
		
		entityTran.begin();
		em.persist(rahul);
		em.persist(manager);
		entityTran.commit();
		
		
	}
}
