package com.cg.main;

import javax.persistence.EntityManager;

import com.cg.beans.Employee;
import com.cg.util.Util;

public class Main {

	
	public static void main(String[] args) {
		System.out.println("Enter the main");
		
		EntityManager managr=Util.getEntityManager();
		
		System.out.println("Brofore Employee");


		Employee emp1=new Employee(1,"Brajesh",1000.0f);
        Employee emp2=new Employee(2,"Mishra",1000.0f);
		
        System.out.println("After Employee");
        System.out.println("hello");
        
        managr.getTransaction().begin();
		managr.persist(emp1);
		managr.persist(emp2);
		managr.getTransaction().commit();
		
		System.out.println("done");
	}
}
