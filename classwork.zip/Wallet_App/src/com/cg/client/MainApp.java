package com.cg.client;

import com.cg.beans.Address;
import com.cg.beans.City;
import com.cg.beans.Country;
import com.cg.repo.EmployeeRepo;
import com.cg.repo.EmployeeRepoImpl;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		City  city=new City();
		city.setCityName("Mathura");
		Country country =new Country();
		country.setCity(city);
		country.setCountryName("India");
		Address address=new Address();
		address.setAddress("Devi Inrayani");
		address.setCountry(country);
		EmployeeRepo empRepoImpl=new EmployeeRepoImpl();
		
		EmployeeService emp=new EmployeeServiceImpl(empRepoImpl);
		emp.createEmployee(1, "Brajesh", address);
		System.out.println(emp.searchByName("Brajesh"));
	}

}
