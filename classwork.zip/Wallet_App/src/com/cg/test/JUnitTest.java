package com.cg.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.beans.Address;
import com.cg.beans.City;
import com.cg.beans.Country;
import com.cg.beans.Employee;
import com.cg.repo.EmployeeRepo;
import com.cg.repo.EmployeeRepoImpl;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;

public class JUnitTest {

	@Test
	public void whenAllDetailsAreCorrectObjectWillBeCreated() {
	 
		City  city=new City();
		city.setCityName("Mathura");
		Country country =new Country();
		country.setCity(city);
		country.setCountryName("India");
		Address address=new Address();
		address.setAddress("Devi Inrayani");
		address.setCountry(country);
		Employee emp = new Employee();
		emp.setId(100);
		emp.setName("BRAJESH");
		emp.setAddress(address);
		
		//emp is dummy object
		
		City city1=new City();
		city1.setCityName("Mathura");
		Country country1 = new Country();
		country1.setCity(city1);
		country1.setCountryName("India");
		Address address1=new Address();
		address1.setAddress("Devi Inrayani");
		address1.setCountry(country1);
		EmployeeRepo empRepoImpl = new EmployeeRepoImpl();
		
		EmployeeService emp1=new EmployeeServiceImpl(empRepoImpl);
		
		assertEquals(emp, emp1.createEmployee(100, "BRAJESH", address1));
		
		
	}

}
