package com.cg.service;

import java.util.List;

import com.cg.beans.Address;
import com.cg.beans.Employee;

public interface EmployeeService {
	Employee createEmployee(int id,String name,Address address);
	List<Employee> searchByName(String name);
	

}
