package com.cg.service;

import java.util.List;

import com.cg.beans.Address;
import com.cg.beans.Employee;
import com.cg.repo.EmployeeRepo;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeRepo empRepoImpl;
	public EmployeeServiceImpl(EmployeeRepo empRepoImpl){
		this.empRepoImpl=empRepoImpl;
	}
	
	@Override
	public Employee createEmployee(int id, String name, Address address) {
		// TODO Auto-generated method stub
		Employee employee=new Employee();
		employee.setId(id);
		employee.setName(name);
		employee.setAddress(address);
		if(empRepoImpl.saveEmp(employee))
		return employee;
		return null;
		
	}

	@Override
	public List<Employee> searchByName(String name) {
		// TODO Auto-generated method stub
		List<Employee> empList=empRepoImpl.findByName(name);
		return empList;
		
	}

}
