package com.cg.repo;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.cg.beans.Employee;

public class EmployeeRepoImpl implements EmployeeRepo{

	Map<Integer,Employee> emp=new HashMap<>();
	
	@Override
	public boolean saveEmp(Employee employee) {
		// TODO Auto-generated method stub
		if(emp.containsKey(employee.getId()))
		return false;
		emp.put(employee.getId(), employee);
		return true;
		
	}

	@Override
	public List<Employee> findByName(String name) {
		// TODO Auto-generated method stub
		List<Employee> listEmployee=new LinkedList<>();
		emp.forEach((k,v)->{
			if(name.equals(v.getName()))
				listEmployee.add(v);
		});
		return listEmployee;
	}
	

}
