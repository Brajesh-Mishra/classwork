package com.cg.repo;

import java.util.List;

import com.cg.beans.Employee;

public interface EmployeeRepo {
	boolean saveEmp(Employee employee);
	List<Employee> findByName(String name);

}
