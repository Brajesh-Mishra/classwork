package com.cg.dao;

import java.util.ArrayList;

import com.cg.beans.Employee;

public interface EmpDAOI {

	public ArrayList<Employee> fetchALL();
	
}
