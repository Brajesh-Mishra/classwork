package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.beans.Employee;
import com.cg.util.Util;

public class EmpDAO implements EmpDAOI{

	@Override
	public ArrayList<Employee> fetchALL() {
		
		System.out.println("In Util");
		
		EntityManager managr=Util.getEntityManager();
		
		Employee emp1=new Employee(1,"Brajesh",1000.0f);
        Employee emp2=new Employee(2,"Mishra",1000.0f);
		
        managr.getTransaction().begin();
		managr.persist(emp1);
		managr.persist(emp2);
		managr.getTransaction().commit();
		
		
		
		Query query=managr.createQuery("Select emp from Employee emp");
		ArrayList<Employee> list=(ArrayList<Employee>) query.getResultList();
		
		
		return list;
	}

	
}
