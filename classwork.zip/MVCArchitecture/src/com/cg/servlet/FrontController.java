package com.cg.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.beans.Employee;
import com.cg.service.EmpService;
import com.cg.service.EmpServiceI;


@WebServlet("*.hr")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url=request.getRequestURI();
		
		
		
		RequestDispatcher dispatch=null;
		
		HttpSession session=null;
	
		switch(getCommand(url)) {
	
		case "*":
		case "homepage":
						dispatch=request.getRequestDispatcher("/WEB-INF/homepage.jsp");
						dispatch.forward(request, response);
						break;
						
		case "loginpage":	dispatch=request.getRequestDispatcher("/WEB-INF/Login.jsp");
							dispatch.forward(request, response);
							break;
		case "Authenticate":if(request.getParameter("username").equals("brajesh") && request.getParameter("password").equals("mishra"))
							{	//getsession() this method is same as passing true by default
								session=request.getSession(true);//it will create session for a user only one time no matter how many times that fucntion is called and if it is there than it will bring reference of that sesssion
								session.setAttribute("fullname", "Brajesh Mishra");
								dispatch=request.getRequestDispatcher("/WEB-INF/JSP.jsp");
								dispatch.forward(request, response);
	                      			
							}
							else {
								request.setAttribute("message","YOU HAVE GIVEN WRONG LOGIN");
								dispatch=request.getRequestDispatcher("/WEB-INF/homepage.jsp");
								dispatch.forward(request, response);
				
							}
							break;
		case "logout":	request.getSession(false).invalidate();
						dispatch=request.getRequestDispatcher("/WEB-INF/thanks.jsp");
						dispatch.forward(request, response);

						break;
		case "list":	EmpServiceI empService=new EmpService();
						ArrayList<Employee> list=empService.fetchALL();
			
						for(Employee emp :list)
							System.out.println(emp);
						
						session.setAttribute("EmpList", list);
						
						dispatch=request.getRequestDispatcher("/WEB-INF/emplist.jsp");
						dispatch.forward(request, response);

						break;
		}
				
	}

	
	
	
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	
	private String getCommand(String url) {
		if(url.lastIndexOf(".")==-1) {
			System.out.println(url);
			return "homepage";
		}
		else
		return url.substring(url.lastIndexOf("/")+1,url.lastIndexOf("."));
	}

}
