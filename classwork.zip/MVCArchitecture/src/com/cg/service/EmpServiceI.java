package com.cg.service;

import java.util.ArrayList;

import com.cg.beans.Employee;

public interface EmpServiceI {

	public ArrayList<Employee> fetchALL();
}
