package com.cg.service;

import java.util.ArrayList;

import com.cg.beans.Employee;
import com.cg.dao.EmpDAO;
import com.cg.dao.EmpDAOI;

public class EmpService implements EmpServiceI {

	public EmpDAOI emp=null;
	
	public EmpService() {
		emp=new EmpDAO();
	}
	
	@Override
	public ArrayList<Employee> fetchALL() {
		
		return emp.fetchALL();
	}

}
