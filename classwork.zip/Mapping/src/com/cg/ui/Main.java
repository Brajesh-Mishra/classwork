package com.cg.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.beans.Address;
import com.cg.beans.Student;
import com.cg.jpa.Util.Util;

public class Main {

	
	public static void main(String[] args) {
		EntityManager entityManager=Util.getEntityManager();
		EntityTransaction entityTran=entityManager.getTransaction();
		
		
		Address address1=new Address();
		address1.setCity("mathura");
		address1.setState("UP");
		address1.setStreet("Gali No 1");
		address1.setZipCode("281121");
		
		Address address2=new Address();
		address2.setCity("mathura");
		address2.setState("UP");
		address2.setStreet("Gali No 1");
		address2.setZipCode("281121");
		
		
		Student student1=new Student();
		student1.setName("brajesh");
		
		student1.setAddress(address1);
	
		Student student2=new Student();
		student2.setName("rahul");
		student2.setAddress(address2);
	
		entityTran.begin();
		entityManager.persist(student1);
		entityManager.persist(student2);
		entityTran.commit();
		
	}
}
