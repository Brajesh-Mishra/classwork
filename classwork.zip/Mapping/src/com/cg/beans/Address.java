package com.cg.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Address {
	
	@Id
	@Column(name="address_id",length=50)
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int address_id;
	

	@Column(name="city",length=50)
	private String city;
	
	@Column(name="state",length=50)
	private String state;
	
	@Column(name="street",length=50)
	private String street;
	
	
	@Column(name="zip_code",length=50)
	private String zipCode;
	
	
	
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Address(String city, String state, String street, String zipCode) {
		super();
		this.city = city;
		this.state = state;
		this.street = street;
		this.zipCode = zipCode;
	}


	
	public int getAddress_id() {
		return address_id;
	}



	public void setAddress_id(int address_id) {
		this.address_id = address_id;
	}


	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getState() {
		return state;
	}



	public void setState(String state) {
		this.state = state;
	}



	public String getStreet() {
		return street;
	}



	public void setStreet(String street) {
		this.street = street;
	}



	public String getZipCode() {
		return zipCode;
	}



	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	
	
	
	
	
	

}
