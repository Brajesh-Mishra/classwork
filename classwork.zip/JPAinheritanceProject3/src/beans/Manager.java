package beans;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="mgr_store")
public class Manager extends Emp{

	
	private String deptName;

	
	public Manager() {
		super();
	}

	

	
	
	
	public Manager(int empId, String empName, float empSalary,String deptname) {
		super(empId, empName, empSalary);
		this.deptName = deptName;
		
	}


	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}


	@Override
	public String toString() {
		return "Manager deptName=" + deptName ;
	}
	
	
	
}
