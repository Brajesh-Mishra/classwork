package com.cg.hr;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/HomePgae")
public class Home extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter printWriter=response.getWriter();
		printWriter.append("<html>");
		printWriter.append("<head>");
		printWriter.append("<title>Home Page</title>");
		printWriter.append("</head>");
	
		printWriter.append("<body>"
				+ "Hello My Name is Brajesh Mishra"
				+ ""
				+ "<a href='Welcome.jsp'>Click for Jsp</a>");
				
		response.sendRedirect("Welcome.jsp");
		printWriter.append("</body>");
		printWriter.append("</html>");
	
	}

}
