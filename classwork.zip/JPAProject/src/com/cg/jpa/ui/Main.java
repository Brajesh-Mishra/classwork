package com.cg.jpa.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.jpa.beans.Employee;
import com.cg.jpa.service.EmployeeService;
import com.cg.jpa.service.EmployeeServiceimpl;

public class Main {

	public static void main(String[] args) {
	
		EmployeeService empService=new EmployeeServiceimpl();
		
		System.out.println("Enter the Choice\n1:\tAdd the Employee\n2:\tFetch All Employeen\n3:\tdelete employe\n4:\tget Employee By Id\n5:\tupdate Employe\n6:\texit");
		Scanner scanner=new Scanner(System.in);
		
		switch(scanner.nextInt()) {
		case 1:
				Employee e1=new Employee();
				
				e1.setEmpName("ramesh");
				e1.setEmpSalary(1000.00f);

				Employee e3=empService.addEmp(e1);
		
				System.out.println("Emplyee added tp databse...........");
	
				System.out.println(e3);
				break;
		case 2:
				ArrayList<Employee> list=empService.fetchAllEmp();
				for(Employee emp:list)
					System.out.println(emp);
				break;
		case 3:
			
				Employee emp=empService.deleteEmp(5);
				System.out.println(emp);
				break;
		case 4:
				System.out.println(empService.getEmpById(5));
				
				break;
		case 5:	
				System.out.println(empService.updateEmp(6, "ramesh", 200.52f));
				break;
		case 6:	System.exit(0);
				break;
		}
		
		
	
		
		
		
	}

}
