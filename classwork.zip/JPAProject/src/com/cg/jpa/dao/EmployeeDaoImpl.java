package com.cg.jpa.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.cg.jpa.Util.Util;
import com.cg.jpa.beans.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	EntityManager em=null;
	EntityTransaction entityTran=null;
	
	public EmployeeDaoImpl() {
		
	em=Util.getEntityManager();
	entityTran=em.getTransaction();
		
	}

	@Override
	public Employee addEmp(Employee emp) {
		
		entityTran.begin();
		em.persist(emp);
		entityTran.commit();
		
		return emp;
	}

	@Override
	public ArrayList<Employee> fetchAllEmp() {
		String query="select emps from Employee emps";
		
		entityTran.begin();
	//	TypedQuery<Employee> tq=em.createQuery(query, Employee.class);
		Query tq=em.createQuery(query);
		ArrayList<Employee> arr=(ArrayList)tq.getResultList();
		entityTran.commit();
		
		
		return arr;
	}

	@Override
	public Employee deleteEmp(int empId) {
		
		entityTran.begin();
		Employee emp=em.find(Employee.class, empId);
		em.remove(emp);
		entityTran.commit();
		return emp;
	}

	@Override
	public Employee getEmpById(int empId) {
		
		
		entityTran.begin();
		Employee emp=em.find(Employee.class, empId);
		entityTran.commit();
		return emp;
	}

	@Override
	public Employee updateEmp(int empId, String name, float salary) {
		entityTran.begin();
		Employee emp=em.find(Employee.class, empId);
		emp.setEmpName(name);
		emp.setEmpSalary(salary);
		em.merge(emp);
		entityTran.commit();
		
		return emp;
	}

}
