package com.cg.jpa.service;

import java.util.ArrayList;

import com.cg.jpa.beans.Employee;
import com.cg.jpa.dao.EmployeeDao;
import com.cg.jpa.dao.EmployeeDaoImpl;

public class EmployeeServiceimpl implements EmployeeService {
	
	EmployeeDao empDao=null;

	public EmployeeServiceimpl() {
		empDao=new EmployeeDaoImpl();
	
	}

	@Override
	public Employee addEmp(Employee emp) {
		return empDao.addEmp(emp);
	}

	@Override
	public ArrayList<Employee> fetchAllEmp() {
		return empDao.fetchAllEmp();
	}

	@Override
	public Employee deleteEmp(int empId) {
		return empDao.deleteEmp(empId);
	}

	@Override
	public Employee getEmpById(int empId) {
		return empDao.getEmpById(empId);
	}

	@Override
	public Employee updateEmp(int empId, String name, float salary) {
		return empDao.updateEmp(empId, name, salary);
	}

}
