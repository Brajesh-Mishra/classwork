package com.cg.inheritance.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.inheritance.beans.Emp;
import com.cg.inheritance.beans.Manager;
import com.cg.inheritance.util.Util;

public class Main {

	public static void main(String []args) {
	
		EntityManager em=Util.getEntityManager();
		EntityTransaction entityTran=em.getTransaction();
		
		Manager manager=new Manager();
		manager.setEmpId(162);
		manager.setEmpName("vaishali");
		manager.setEmpSalary(5002.00f);
		manager.setDeptName("Java");
		
		
		
		entityTran.begin();
	
		em.persist(manager);
		entityTran.commit();
		
		
	}
}
