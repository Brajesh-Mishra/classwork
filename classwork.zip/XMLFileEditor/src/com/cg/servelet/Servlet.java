package com.cg.servelet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/Servlet")
public class Servlet extends HttpServlet {
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			ServletContext text=getServletContext();
			System.out.println(text.getInitParameter("companyname"));
			
			
			System.out.println("barjesh");
			
			ServletConfig config=getServletConfig();
			System.out.println(config.getInitParameter("capgemini"));
	}

	
}
