package com.cg.service;

import java.math.BigDecimal;

import com.cg.bean.Customer;
import com.cg.bean.Wallet;
import com.cg.repo.IWalletRepoSerive;

public class WalletServiceImpl implements IWalletSerive {
	
IWalletRepoSerive iWalletRepoService;	

public WalletServiceImpl(IWalletRepoSerive iWalletRepoService) {
	this.iWalletRepoService=iWalletRepoService;
	
}	

public Customer createAccount(String name,String phone,BigDecimal bigdecimal) {
		Customer customer=new Customer();
		customer.setName(name);
		customer.setPhone(phone);
		
		Wallet wallet=new Wallet();
		wallet.setBalance(bigdecimal);
		wallet.setId(1);
		
		customer.setWallet(wallet);
		
		if(iWalletRepoService.save(customer))
		return customer;
		
		return null;
		
	}
	
	public Customer showByName(String name) {
		
		if((iWalletRepoService.showByName(name))!=null) {
			
			return iWalletRepoService.showByName(name);
			}
		 
		return null;
		
	}
}
