package com.cg.service;

import java.math.BigDecimal;

import com.cg.bean.Customer;

public interface IWalletSerive {
	
	public Customer createAccount(String name,String phone,BigDecimal bigdecimal);
	public Customer showByName(String name);
}