package com.cg.repo;

import java.math.BigDecimal;

import com.cg.bean.Customer;

public interface IWalletRepoSerive {
	public boolean save(Customer customer);
	public Customer showByName(String name);
}