package com.cg.repo;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.bean.Customer;

public class WalletRepoServiceImpl implements IWalletRepoSerive  {
	Map<Integer,Customer> map=new HashMap<>();
	public boolean save(Customer customer) {
		
		if(map.containsKey(customer.getWallet().getId()))
			return false;
		map.put(customer.getWallet().getId(), customer);
	
		
		return true;
		
	}
	public Customer showByName(String name) {
		

		for(Entry<Integer, Customer> entry:map.entrySet()) {
			if(entry.getValue().getName().equals(name))
				return entry.getValue();
		}
		return null;
		
	}

}
