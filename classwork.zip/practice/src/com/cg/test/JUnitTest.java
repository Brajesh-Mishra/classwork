package com.cg.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class JUnitTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
