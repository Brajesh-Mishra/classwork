package com.cg.client;

import java.math.BigDecimal;

import com.cg.repo.IWalletRepoSerive;
import com.cg.repo.WalletRepoServiceImpl;
import com.cg.service.IWalletSerive;
import com.cg.service.WalletServiceImpl;

public class Client {
public static void main(String[] args) {
	IWalletRepoSerive iWalletRepoService=new WalletRepoServiceImpl();
	IWalletSerive iWalletSerice=new WalletServiceImpl(iWalletRepoService);
	BigDecimal bigDecimal=new BigDecimal("100000");
	iWalletSerice.createAccount("Brajesh", "7895930092", bigDecimal);
	
	System.out.println(iWalletSerice.showByName("Brajesh")+"1");
	
}
}
