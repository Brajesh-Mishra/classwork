package com.cg.beans;

import java.util.ArrayList;
import java.util.HashMap;

public class Employee {

	int emp_id;
	String emp_name;
	float emp_salary;
	ArrayList<Integer>   list;
	HashMap<Integer,String> map;
	

	public ArrayList<Integer> getList() {
		return list;
	}

	public void setMap(HashMap<Integer, String> map) {
		this.map = map;
	}

	public void setList(ArrayList<Integer> list) {
		this.list = list;
	}

	public HashMap<Integer, String> getMap() {
		return map;
	}



	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int emp_id, String emp_name, float emp_salary) {
		super();
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.emp_salary = emp_salary;
	}

	public int getEmp_id() {
		return emp_id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public float getEmp_salary() {
		return emp_salary;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public void setEmp_salary(float emp_salary) {
		this.emp_salary = emp_salary;
	}

	@Override
	public String toString() {
		return "Employee [emp_id=" + emp_id + ", emp_name=" + emp_name + ", emp_salary=" + emp_salary + "]";
	}

}
