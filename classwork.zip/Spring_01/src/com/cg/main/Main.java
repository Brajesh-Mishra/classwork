package com.cg.main;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.cg.beans.Employee;

public class Main {

	public static void main(String[] args) {

		XmlBeanFactory factory = new XmlBeanFactory(new ClassPathResource("beans.xml"));
		Employee emp = (Employee) factory.getBean("employee");
		System.out.println(emp);
		

		Employee emp1 = (Employee) factory.getBean("employee1");
		System.out.println(emp1);
		
		System.out.println(emp1.getList());
		System.out.println(emp1.getMap());

	}

}
